<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>DataBase Error</h1>
    <p>You have an error connecting to the database</p>
    <p><?php $error_message ?> <p>
</body>
</html>